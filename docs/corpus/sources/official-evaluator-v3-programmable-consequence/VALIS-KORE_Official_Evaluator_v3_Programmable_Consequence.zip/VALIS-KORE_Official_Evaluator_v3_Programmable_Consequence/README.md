# VALIS-KORE Official Evaluator v3 — Programmable Consequence

This build integrates the Programmable Consequence orientation layer into the canonical cream / charcoal / gold evaluator while preserving the deeper CR architecture, evidence, conformance, research, and reproduction surfaces.

Key wording hierarchy:
- Programmable Consequence — public/category concept
- Consequence Boundary — architectural locus
- Consequential Reach — bounded scope of consequence
- Consequential Reachability (CR) — formal computational property

The decision-volume interaction is explicitly illustrative and does not present synthetic counts as empirical evidence.
